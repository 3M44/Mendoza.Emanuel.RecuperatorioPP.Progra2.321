package com.mycompany.bibliotecamain;


public class Ilustracion extends Publicacion{
    private String nombre;
    private double ancho;
    private double alto;

    public Ilustracion(String titulo, String anioPublicacion, String nombre, double ancho, double alto) {
        super(titulo, anioPublicacion);
        this.nombre = nombre;
        this.ancho = ancho;
        this.alto = alto;
    }
    
    @Override
    public String toString() {
        return "[Ilustrador= " + nombre + ", ancho= " + ancho + ", alto= " + alto + "]";
    }
}
