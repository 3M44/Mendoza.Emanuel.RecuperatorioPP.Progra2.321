package com.mycompany.bibliotecamain;


public interface Leer {
    
    void Leer();
}
