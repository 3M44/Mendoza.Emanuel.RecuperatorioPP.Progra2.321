package com.mycompany.bibliotecamain;

public class BibliotecaMain {

    public static void main(String[] args) {
        Biblioteca b = new Biblioteca("Jose");
        
        Libro L = new Libro("jose", Genero.CIENCIA, "auto", "11/12/2024");
        Revista R = new Revista("guerra", "21/3/2020", 123);
        Ilustracion I = new Ilustracion("ilu", "12/4/1999", "juan", 200, 300);
        
        try{
        b.agregarPublicacion(I);
        b.agregarPublicacion(R);
        b.agregarPublicacion(L);
        }
        catch(PublicacionRepetidaException p){
            p.getMessage();
        }
        
        b.mostrarPublicaciones();
        
        System.out.println("--------------------------");
        
        b.leerPublicaciones();
    }
}
