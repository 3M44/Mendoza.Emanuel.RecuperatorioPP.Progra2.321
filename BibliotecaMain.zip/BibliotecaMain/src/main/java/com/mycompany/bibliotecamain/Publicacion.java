package com.mycompany.bibliotecamain;

import java.util.Objects;

public abstract class Publicacion {
    private String titulo;
    private String anioPublicacion;

    public Publicacion(String titulo, String anioPublicacion) {
        this.titulo = titulo;
        this.anioPublicacion = anioPublicacion;
    }

    public String getTitulo(){
        return titulo;
    }
    
    
    @Override
    public int hashCode() {
        return Objects.hash(titulo, anioPublicacion);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass()){
            return false;
        }
        Publicacion other = (Publicacion) o;
        return other.titulo.equals(titulo) && other.anioPublicacion.equals(anioPublicacion);
    }

    
}
