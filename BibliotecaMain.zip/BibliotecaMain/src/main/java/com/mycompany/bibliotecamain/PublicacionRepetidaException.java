package com.mycompany.bibliotecamain;


public class PublicacionRepetidaException extends RuntimeException{
    private static final String MSG = "Publicacion repetida";
    
    public PublicacionRepetidaException(){
        super(MSG);
    }
}

