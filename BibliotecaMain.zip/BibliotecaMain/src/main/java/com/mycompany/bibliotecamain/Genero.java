package com.mycompany.bibliotecamain;


public enum Genero {
    FICCION,
    NO_FICCION,
    CIENCIA,
    HISTORIA;
}
