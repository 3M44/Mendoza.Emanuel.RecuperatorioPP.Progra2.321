package com.mycompany.bibliotecamain;


public class Libro extends Publicacion implements Leer{
    private String autor;
    private Genero genero;

    public Libro(String titulo, Genero genero, String autor, String anioPublicacion) {
        super(titulo, anioPublicacion);
        this.autor = autor;
        this.genero = genero;
    }

    

    @Override
    public void Leer() {
        System.out.println("El libro " + getTitulo() + " se esta leyendo");
    }

    @Override
    public String toString() {
        return "[autor= " + autor + ", genero= " + genero + ']';
    }
    
   
    
}
