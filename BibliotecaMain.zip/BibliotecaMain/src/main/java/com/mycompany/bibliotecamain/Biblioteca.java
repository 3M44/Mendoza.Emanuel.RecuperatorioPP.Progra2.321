package com.mycompany.bibliotecamain;

import java.util.ArrayList;

public class Biblioteca {
    private String nombre;
    
    private ArrayList<Publicacion> publicaciones = new ArrayList<>();

    public Biblioteca(String nombre) {
        this.nombre = nombre;
    }
    
    public void agregarPublicacion(Publicacion publicacion){
        for (Publicacion p : publicaciones)
            if (p.equals(publicacion)){
                throw new PublicacionRepetidaException();
            }
        publicaciones.add(publicacion);
    }
    
    public void mostrarPublicaciones(){
        for (Publicacion p : publicaciones){
            System.out.println(p);
        }
    }
    
    public void leerPublicaciones(){
        for(Publicacion p : publicaciones){
            if (p instanceof Leer leible){
                leible.Leer();
            }
            else {
                System.out.println(p.getTitulo() + " no se puede leer");
            }
        }
    }
    
}
