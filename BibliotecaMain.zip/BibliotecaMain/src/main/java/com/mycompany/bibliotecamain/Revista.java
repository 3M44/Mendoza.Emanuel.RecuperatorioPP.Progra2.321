package com.mycompany.bibliotecamain;


public class Revista extends Publicacion implements Leer{
    private int numero;

    public Revista(String titulo, String anioPublicacion, int numero) {
        super(titulo, anioPublicacion);
        this.numero = numero;
    }

    @Override
    public void Leer() {
        System.out.println("La revista " + getTitulo() + " se esta leyendo");
    }
    
    @Override
    public String toString() {
        return "[numeroEdicion= " + numero + "]";
    }
}
